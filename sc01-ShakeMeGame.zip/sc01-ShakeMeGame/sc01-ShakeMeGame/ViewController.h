//
//  ViewController.h
//  sc01-ShakeMeGame
//
//  Created by user on 10/2/17.
//  Copyright © 2017 user. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

